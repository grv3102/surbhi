var express = require('express');
var app = express();
var mongoose = require('mongoose');
var bodyParser = require('body-parser');

var books =  require('./routes/books');

mongoose.connect('mongodb://localhost:27017/book_collection',{useNewUrlParser: true, useUnifiedTopology: true}, (err)=>{
    if(!err)
        console.log('Connect to DB');
});
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));

//Routes Middleware
app.use('/book/books', books);

app.listen(3000, ()=>console.log('Server is listening to the Port 3000'));