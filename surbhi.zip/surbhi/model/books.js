var mongoose = require('mongoose');

var Books = new mongoose.Schema({
   
  
    books_list: [{
        name: String,
        img: String,
        summary: String,
        
    }]
});

module.exports = mongoose.model('Books', Books);