
var router = require('express').Router();


var Books= require('../model/books');



router.get('/',async (req,res)=>{
    Books.find((err,docs)=>{
        if(!err){
            res.send(docs);
        }
        else{
            console.log('Error in  Retriving Books: '+JSON.stringify(err, undefined, 2));
        }
        });
});

router.post('/', async (req,res)=>{       
        var books = new Books({
           books_list : req.body.books_list
           
        });
        try{
            var Result, Message;
            if(books.save()){
                Result = 1;
                Message = "Successfully Books record Created";
            }else{
                Result = 0;
                Message = "Failed to Generate";
            }
            
            res.send("Result : "+Result+"\n"+"Message : " + Message);
        }catch(err){
            res.status(400).send(err);
        }
});



module.exports = router;